CO5 ASSIGNMENT 5 PACKAGE
Student Name: Varun Babu M R
Register Number: 1924260211
GitHub Repository: CSA02-1924260211-Assignment5

Contents
- CO5_Assignment_5_Report.pdf: complete Part A (SIMATS pseudocode, structure charts, call traces, pointer diagrams) and Part B (GCC source code, terminal screenshots, charts, benchmarks & AddressSanitizer verification) report.
- C_Programs/: standard C11 programs for B1 through B4 (5 programs).
- Screenshots/: terminal-style PNG captures pairing each C source file with its actual GCC 12.2.0 compilation command and execution output.
- Program_Outputs/: compiled binaries and plain-text output captures.
- Data_Files/: generated 100,000-record text and binary donor benchmark datasets.
- Experimental_Results.xlsx: B1 recursion call scaling, B3 text vs binary measurements, and B4 250,000-donor report metrics.

Compilation & Execution
  gcc -std=c11 -Wall -Wextra -O2 <source.c> -o <executable>
  gcc -std=c11 -Wall -Wextra -fsanitize=address -g B4_growable_donor_report.c -o B4_asan
