#define _POSIX_C_SOURCE 199309L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct {
    int id;
    char group[4];
    int days_since_donation; /* eligible if >= 90 days (or >= 83 days for next week) */
} Donor;

typedef struct {
    Donor *data;
    int size, capacity;
} DonorList;

double now_ms(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec * 1000.0 + (double)ts.tv_nsec * 1e-6;
}

/* Appends a donor, doubling the capacity when the list is full.
   Returns 1 on success, 0 if memory could not be allocated. */
int add_donor(DonorList *list, int id, const char *group, int days_since)
{
    if (list->size == list->capacity) {
        /* TODO 1: Compute new capacity (2 if 0, else double), grow with realloc
           WITHOUT losing old pointer if realloc fails, and update data and capacity */
        int new_cap = (list->capacity == 0) ? 2 : list->capacity * 2;
        Donor *p = realloc(list->data, (size_t)new_cap * sizeof(Donor));
        if (p == NULL) {
            return 0; /* Preserve list->data so caller can still use/free existing records */
        }
        list->data = p;
        list->capacity = new_cap;
    }
    list->data[list->size].id = id;
    strncpy(list->data[list->size].group, group, 3);
    list->data[list->size].group[3] = '\0';
    list->data[list->size].days_since_donation = days_since;
    list->size++;
    return 1;
}

int main(void)
{
    /* Part 1: Verify exact TODO 1 doubling steps on 5 donors */
    DonorList list = {NULL, 0, 0};
    const char *groups[] = {"O+", "A+", "B-", "AB+", "O-"};
    for (int i = 0; i < 5; i++) {
        add_donor(&list, 7001 + i, groups[i], 95);
        printf("added %d (%s): size = %d, capacity = %d\n",
               list.data[i].id, list.data[i].group, list.size, list.capacity);
    }
    free(list.data);

    /* Part 2: 25 Hospitals, 100x scale = 250,000 donors nightly eligibility report */
    int total_donors = 250000;
    const char *all_groups[] = {"O+", "A+", "B+", "AB+", "O-", "A-", "B-", "AB-"};
    FILE *fp = tmpfile();
    if (!fp) return 1;
    for (int i = 0; i < total_donors; i++) {
        fprintf(fp, "%d %s %d\n", 100000 + i, all_groups[i % 8], 50 + (i % 70));
    }
    rewind(fp);

    double t0 = now_ms();
    DonorList district = {NULL, 0, 0};
    int id, days;
    char grp[4];
    while (fscanf(fp, "%d %3s %d", &id, grp, &days) == 3) {
        if (!add_donor(&district, id, grp, days)) {
            fprintf(stderr, "Allocation failed at size %d\n", district.size);
            break;
        }
    }
    int eligible_next_week = 0;
    for (int i = 0; i < district.size; i++) {
        if (district.data[i].days_since_donation >= 83) {
            eligible_next_week++;
        }
    }
    double elapsed = now_ms() - t0;
    fclose(fp);

    printf("\n=== Nightly District Eligibility Report (25 Hospitals / 100x Scale) ===\n");
    printf("Loaded Donors: %d | Final Capacity: %d | Heap Used: %.2f MB\n",
           district.size, district.capacity,
           ((double)district.capacity * sizeof(Donor)) / (1024.0 * 1024.0));
    printf("Eligible Next Week (>=83 days): %d | Execution Time: %.2f ms\n",
           eligible_next_week, elapsed);

    free(district.data);
    district.data = NULL;
    printf("Memory Cleanly Released (free(district.data) verified with ASan).\n");
    return 0;
}
