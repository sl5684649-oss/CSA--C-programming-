#include <stdio.h>

long long calls = 0; /* number of recursive calls made */

/* Linear recursion: base^exp = base * base^(exp-1) */
long long power_linear(long long base, int exp)
{
    calls++;
    if (exp == 0) return 1;
    return base * power_linear(base, exp - 1);
}

/* Divide-and-conquer recursion: compute base^(exp/2) once and square it. */
long long power_fast(long long base, int exp)
{
    calls++;
    /* TODO 1: Base case for exp == 0; otherwise compute half = power_fast(base, exp / 2)
       ONCE and return half * half, multiplied by base when exp is odd */
    if (exp == 0) return 1;
    long long half = power_fast(base, exp / 2);
    if (exp % 2 == 0) {
        return half * half;
    } else {
        return base * half * half;
    }
}

/* Unoptimized double-call variant for comparison */
long long power_fast_unopt(long long base, int exp)
{
    calls++;
    if (exp == 0) return 1;
    if (exp % 2 == 0)
        return power_fast_unopt(base, exp / 2) * power_fast_unopt(base, exp / 2);
    else
        return base * power_fast_unopt(base, exp / 2) * power_fast_unopt(base, exp / 2);
}

int digital_root(long long n)
{
    calls++;
    if (n < 0) n = -n;
    if (n < 10) return (int)n;
    long long sum = 0;
    while (n > 0) {
        sum += n % 10;
        n /= 10;
    }
    return digital_root(sum);
}

long long power_iter(long long base, int exp)
{
    long long result = 1;
    while (exp > 0) {
        if (exp & 1) result *= base;
        base *= base;
        exp >>= 1;
    }
    return result;
}

int main(void)
{
    calls = 0;
    long long a = power_linear(2, 30);
    printf("linear: %lld in %lld calls\n", a, calls);

    calls = 0;
    long long b = power_fast(2, 30);
    printf("fast  : %lld in %lld calls\n", b, calls);

    calls = 0;
    long long c = power_fast_unopt(2, 30);
    printf("double-call fast(2,30): %lld in %lld calls\n", c, calls);

    /* Validation table: ordinary, 0, 1, and custom */
    int test_exps[] = {0, 1, 5, 10, 100, 1000, 10000};
    printf("\n--- Call Count Scaling (n = 10, 100, 1000, 10000) ---\n");
    for (int i = 0; i < 7; i++) {
        int e = test_exps[i];
        calls = 0; (void)power_linear(1, e); long long c_lin = calls;
        calls = 0; (void)power_fast(1, e);   long long c_fst = calls;
        long long it_v = power_iter(1, e);
        printf("n=%-5d | linear_calls=%-6lld | fast_calls=%-3lld | iter_val=%lld\n",
               e, c_lin, c_fst, it_v);
    }

    long long dr_inputs[] = {0, 1, 9, 9875, 1924260211LL};
    printf("\n--- Digital Root Validation ---\n");
    for (int i = 0; i < 5; i++) {
        calls = 0;
        int dr = digital_root(dr_inputs[i]);
        printf("digital_root(%lld) = %d (calls = %lld)\n", dr_inputs[i], dr, calls);
    }
    return 0;
}
