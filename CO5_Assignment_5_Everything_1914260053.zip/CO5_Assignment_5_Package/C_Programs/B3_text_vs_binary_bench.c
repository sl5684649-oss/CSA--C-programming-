#define _POSIX_C_SOURCE 199309L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct {
    int id;
    char name[24];
    char group[4];
    int age;
    char phone[12];
    int days_since_last;
} DonorRec;

double now_ms(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec * 1000.0 + (double)ts.tv_nsec * 1e-6;
}

long file_bytes(const char *path)
{
    FILE *f = fopen(path, "rb");
    if (!f) return -1;
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fclose(f);
    return sz;
}

int main(void)
{
    int sizes[] = {10, 1000, 10000, 100000};
    const char *groups[] = {"O+", "A+", "B+", "AB+", "O-", "A-", "B-", "AB-"};

    for (int s = 0; s < 4; s++) {
        int n = sizes[s];
        DonorRec *arr = malloc((size_t)n * sizeof(DonorRec));
        for (int i = 0; i < n; i++) {
            arr[i].id = 100000 + i;
            snprintf(arr[i].name, sizeof(arr[i].name), "Donor_%06d", i);
            strcpy(arr[i].group, groups[i % 8]);
            arr[i].age = 20 + (i % 40);
            snprintf(arr[i].phone, sizeof(arr[i].phone), "98%08d", i % 100000000);
            arr[i].days_since_last = 30 + (i % 150);
        }

        /* Text Write */
        double t0 = now_ms();
        FILE *ft = fopen("/tmp/donors_bench.txt", "w");
        for (int i = 0; i < n; i++) {
            fprintf(ft, "%d %s %s %d %s %d\n", arr[i].id, arr[i].name, arr[i].group,
                    arr[i].age, arr[i].phone, arr[i].days_since_last);
        }
        fclose(ft);
        double t_tw = now_ms() - t0;

        /* Text Read */
        t0 = now_ms();
        ft = fopen("/tmp/donors_bench.txt", "r");
        DonorRec tmp;
        int r_txt = 0;
        while (fscanf(ft, "%d %23s %3s %d %11s %d", &tmp.id, tmp.name, tmp.group,
                      &tmp.age, tmp.phone, &tmp.days_since_last) == 6) {
            r_txt++;
        }
        fclose(ft);
        double t_tr = now_ms() - t0;

        /* Binary Write */
        t0 = now_ms();
        FILE *fb = fopen("/tmp/donors_bench.bin", "wb");
        fwrite(arr, sizeof(DonorRec), (size_t)n, fb);
        fclose(fb);
        double t_bw = now_ms() - t0;

        /* Binary Read */
        t0 = now_ms();
        fb = fopen("/tmp/donors_bench.bin", "rb");
        size_t r_bin = fread(arr, sizeof(DonorRec), (size_t)n, fb);
        fclose(fb);
        double t_br = now_ms() - t0;

        long sz_txt = file_bytes("/tmp/donors_bench.txt");
        long sz_bin = file_bytes("/tmp/donors_bench.bin");

        printf("n=%-6d | Txt: %7ld B (W=%.2fms, R=%.2fms, cnt=%d) | Bin: %7ld B (W=%.2fms, R=%.2fms, cnt=%zu)\n",
               n, sz_txt, t_tw, t_tr, r_txt, sz_bin, t_bw, t_br, r_bin);

        if (n == 100000) {
            /* B3.3: Update 50,000th record (index 49999) */
            double u0 = now_ms();
            fb = fopen("/tmp/donors_bench.bin", "r+b");
            fseek(fb, 49999L * (long)sizeof(DonorRec), SEEK_SET);
            fread(&tmp, sizeof(DonorRec), 1, fb);
            tmp.days_since_last = 0;
            fseek(fb, -(long)sizeof(DonorRec), SEEK_CUR);
            fwrite(&tmp, sizeof(DonorRec), 1, fb);
            fclose(fb);
            double t_bin_upd = now_ms() - u0;

            u0 = now_ms();
            ft = fopen("/tmp/donors_bench.txt", "r");
            int k = 0;
            while (fscanf(ft, "%d %23s %3s %d %11s %d", &arr[k].id, arr[k].name, arr[k].group,
                          &arr[k].age, arr[k].phone, &arr[k].days_since_last) == 6) k++;
            fclose(ft);
            arr[49999].days_since_last = 0;
            ft = fopen("/tmp/donors_bench.txt", "w");
            for (int i = 0; i < k; i++) {
                fprintf(ft, "%d %s %s %d %s %d\n", arr[i].id, arr[i].name, arr[i].group,
                        arr[i].age, arr[i].phone, arr[i].days_since_last);
            }
            fclose(ft);
            double t_txt_upd = now_ms() - u0;
            printf("Update Record #50,000 -> Binary fseek: %.4f ms | Text full-rewrite: %.4f ms (%.0fx faster)\n",
                   t_bin_upd, t_txt_upd, t_txt_upd / (t_bin_upd > 0.0001 ? t_bin_upd : 0.0001));
        }
        free(arr);
    }
    return 0;
}
