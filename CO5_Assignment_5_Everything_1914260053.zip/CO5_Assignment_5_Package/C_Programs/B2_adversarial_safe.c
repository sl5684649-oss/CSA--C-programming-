#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#define NAME_MAX_LEN 16

int is_valid_group(const char *g)
{
    const char *valid[] = {"A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"};
    for (int i = 0; i < 8; i++) {
        if (strcmp(g, valid[i]) == 0) return 1;
    }
    return 0;
}

int main(int argc, char *argv[])
{
    printf("=== 1. CLI Argument Validation ===\n");
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <find|issue> <blood_group> (received argc=%d)\n", argv[0], argc);
    } else if (!is_valid_group(argv[2])) {
        fprintf(stderr, "Error: Invalid blood group '%s'\n", argv[2]);
    } else {
        printf("CLI Validated: command='%s', group='%s'\n", argv[1], argv[2]);
    }

    printf("\n=== 2. Safe Bounded Input (fgets vs unsafe scanf(\"%%s\")) ===\n");
    const char *long_input = "Thiruvengadam_Subramanian_LongName\n";
    char safe_buf[NAME_MAX_LEN];
    /* Simulate reading overlong line safely with fgets */
    snprintf(safe_buf, sizeof(safe_buf), "%.*s", (int)(sizeof(safe_buf) - 1), long_input);
    safe_buf[strcspn(safe_buf, "\n")] = '\0';
    printf("Buffer size = %d | Safely truncated name = '%s' (len=%zu, no overflow)\n",
           NAME_MAX_LEN, safe_buf, strlen(safe_buf));

    printf("\n=== 3. Missing Data File Handling with perror() ===\n");
    FILE *fp = fopen("non_existent_donors.txt", "r");
    if (fp == NULL) {
        perror("fopen(non_existent_donors.txt)");
    } else {
        fclose(fp);
    }

    printf("\n=== 4. Dynamic Heap Allocation & Clean Free (ASan Verified) ===\n");
    char *dyn_name = malloc(64);
    if (dyn_name != NULL) {
        snprintf(dyn_name, 64, "%s", "Varun Babu M R");
        printf("Allocated donor buffer: '%s'\n", dyn_name);
        free(dyn_name);
        dyn_name = NULL;
    }
    return 0;
}
