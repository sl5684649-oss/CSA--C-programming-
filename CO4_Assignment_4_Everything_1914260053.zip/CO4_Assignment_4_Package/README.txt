CO4 ASSIGNMENT 4 PACKAGE
Student Name: Varun Babu M R
Register Number: 1924260211
GitHub Repository: CSA02-1924260211-Assignment4

Contents
- CO4_Assignment_4_Report.pdf: complete individual report with diagnoses, SIMATS pseudocode, memory layout analyses, and embedded GCC terminal screenshots for Task 1 through Task 6.
- C_Programs/: standard C11 source files for Task01 through Task06 (7 programs).
- Screenshots/: terminal-style PNG captures pairing each C source file with its actual GCC 12.2.0 compilation command and execution output.
- Program_Outputs/: compiled binaries and plain-text output captures.
- Memory_Layout_Measurements.xlsx: predicted vs measured sizeof values and padding breakdown.

Compilation & Execution
All programs were compiled cleanly with zero warnings using:
  gcc -std=c11 -Wall -Wextra <source.c> -o <executable>
