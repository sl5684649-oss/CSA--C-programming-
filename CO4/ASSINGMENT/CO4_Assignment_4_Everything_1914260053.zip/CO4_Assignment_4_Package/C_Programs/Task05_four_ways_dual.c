#include <stdio.h>

/* Simulates two translation units (file1 + file2) via extern linkage */
int veg_global_token = 1000;
int nonveg_global_token = 2000;

int next_auto(void) {
    auto int t = 1000;
    return ++t;
}

int next_static_veg(void) {
    static int t = 1000;
    return ++t;
}

int next_static_nonveg(void) {
    static int t = 2000;
    return ++t;
}

int next_extern_veg(void) {
    extern int veg_global_token;
    return ++veg_global_token;
}

int next_extern_nonveg(void) {
    extern int nonveg_global_token;
    return ++nonveg_global_token;
}

int main(void)
{
    printf("(a) auto   (3 calls): ");
    for (register int i = 0; i < 3; i++) printf("%d ", next_auto());
    printf("\n(b) static Veg / Non-Veg: %d %d | %d %d\n",
           next_static_veg(), next_static_veg(), next_static_nonveg(), next_static_nonveg());
    printf("(c) extern Veg / Non-Veg: %d %d | %d %d\n",
           next_extern_veg(), next_extern_veg(), next_extern_nonveg(), next_extern_nonveg());
    return 0;
}
