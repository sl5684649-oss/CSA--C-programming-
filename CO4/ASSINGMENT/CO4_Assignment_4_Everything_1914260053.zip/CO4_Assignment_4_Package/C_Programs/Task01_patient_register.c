#include <stdio.h>
#include <string.h>

#define MAX_PATIENTS 100

typedef struct {
    int day;
    int month;
    int year;
} Date;

typedef struct {
    int systolic;
    int diastolic;
} BloodPressure;

typedef struct {
    char name[40];
    int age;
    char phone[15]; /* 10 digits + optional country code + '\0' */
    BloodPressure bp;
    Date visitDate;
} Patient;

typedef struct {
    Patient records[MAX_PATIENTS];
    int count;
} PatientRegister;

int addPatient(PatientRegister *reg, const Patient *p)
{
    if (reg == NULL || p == NULL || reg->count >= MAX_PATIENTS) {
        return 0; /* Full or invalid pointer */
    }
    reg->records[reg->count] = *p;
    reg->count++;
    return 1;
}

void sortByAge(PatientRegister *reg)
{
    for (int i = 0; i < reg->count - 1; i++) {
        int min_idx = i;
        for (int j = i + 1; j < reg->count; j++) {
            if (reg->records[j].age < reg->records[min_idx].age) {
                min_idx = j;
            }
        }
        if (min_idx != i) {
            Patient tmp = reg->records[i];
            reg->records[i] = reg->records[min_idx];
            reg->records[min_idx] = tmp;
        }
    }
}

int main(void)
{
    PatientRegister reg = { .count = 0 };
    Patient p1 = {"Ananya Rao", 42, "9876543210", {120, 80}, {18, 11, 2026}};
    Patient p2 = {"Karthik S",  25, "9123456789", {118, 76}, {19, 11, 2026}};
    Patient p3 = {"Meena Devi", 61, "9988776655", {145, 92}, {19, 11, 2026}};

    addPatient(&reg, &p1);
    addPatient(&reg, &p2);
    addPatient(&reg, &p3);

    printf("sizeof(Patient) = %zu bytes | sizeof(PatientRegister) = %zu bytes\n",
           sizeof(Patient), sizeof(PatientRegister));
    sortByAge(&reg);
    printf("--- Patients Sorted by Age ---\n");
    for (int i = 0; i < reg.count; i++) {
        const Patient *pt = &reg.records[i];
        printf("%-12s | Age: %2d | Phone: %s | BP: %d/%d | Visit: %02d/%02d/%04d\n",
               pt->name, pt->age, pt->phone, pt->bp.systolic, pt->bp.diastolic,
               pt->visitDate.day, pt->visitDate.month, pt->visitDate.year);
    }
    return 0;
}
