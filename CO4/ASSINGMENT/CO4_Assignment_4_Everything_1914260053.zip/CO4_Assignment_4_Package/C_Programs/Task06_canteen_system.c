#include <stdio.h>
#include <string.h>

#define MAX_ITEMS 50

typedef struct {
    int day, month, year;
} Date;

typedef struct {
    int hour, minute;
} Time24;

typedef enum {
    ITEM_PACKAGED,
    ITEM_COOKED,
    ITEM_COMBO
} ItemCategory;

typedef struct {
    int sub_item_ids[3];
    int sub_count;
} ComboDetails;

typedef union {
    Date expiry_date;        /* for ITEM_PACKAGED */
    Time24 prepared_time;    /* for ITEM_COOKED */
    ComboDetails combo;      /* for ITEM_COMBO */
} ItemMeta;

typedef struct {
    int id;
    char name[32];
    float price;
    int stock;
    int units_sold;
    float revenue;
    ItemCategory category;
    ItemMeta meta;
} CanteenItem;

/* Convert Date to serial days for exact <= 2 day expiry comparison */
long to_serial_days(Date d)
{
    return (long)d.year * 365 + (long)d.month * 30 + d.day;
}

int record_sale(CanteenItem *item, int qty)
{
    if (item == NULL || qty <= 0) return 0;
    if (qty > item->stock) {
        printf("[SALE REJECTED] %s: requested %d, available stock = %d\n",
               item->name, qty, item->stock);
        return 0;
    }
    item->stock -= qty;
    item->units_sold += qty;
    item->revenue += item->price * (float)qty;
    printf("[SALE OK] Sold %d x %s (Rs %.2f) | Remaining Stock: %d\n",
           qty, item->name, item->price * (float)qty, item->stock);
    return 1;
}

void warn_expiring_items(const CanteenItem items[], int n, Date today)
{
    long today_days = to_serial_days(today);
    printf("\n--- Expiry Alert Check (Today: %02d/%02d/%04d, Window <= 2 days) ---\n",
           today.day, today.month, today.year);
    int alerts = 0;
    for (int i = 0; i < n; i++) {
        if (items[i].category == ITEM_PACKAGED) {
            long diff = to_serial_days(items[i].meta.expiry_date) - today_days;
            if (diff >= 0 && diff <= 2) {
                printf("  [WARNING] ID %d (%s) expires on %02d/%02d/%04d (in %ld day(s))\n",
                       items[i].id, items[i].name,
                       items[i].meta.expiry_date.day, items[i].meta.expiry_date.month,
                       items[i].meta.expiry_date.year, diff);
                alerts++;
            }
        }
    }
    if (alerts == 0) printf("  No packaged items expiring within 2 days.\n");
}

void print_revenue_summary(CanteenItem items[], int n)
{
    /* Selection sort descending by revenue */
    for (int i = 0; i < n - 1; i++) {
        int max_idx = i;
        for (int j = i + 1; j < n; j++) {
            if (items[j].revenue > items[max_idx].revenue) max_idx = j;
        }
        if (max_idx != i) {
            CanteenItem tmp = items[i];
            items[i] = items[max_idx];
            items[max_idx] = tmp;
        }
    }
    float total_rev = 0.0f;
    printf("\n--- Daily Canteen Billing Summary (Sorted by Revenue) ---\n");
    for (int i = 0; i < n; i++) {
        total_rev += items[i].revenue;
        printf("  #%d ID:%-3d %-18s | Sold:%2d | Stock:%2d | Revenue: Rs %7.2f\n",
               i + 1, items[i].id, items[i].name, items[i].units_sold,
               items[i].stock, items[i].revenue);
    }
    printf("Total Daily Revenue: Rs %.2f\n", total_rev);
}

int main(void)
{
    CanteenItem menu[4] = {
        {101, "Fruit Juice",    35.0f, 10, 0, 0.0f, ITEM_PACKAGED, {.expiry_date = {20, 11, 2026}}},
        {102, "Protein Bar",    50.0f, 15, 0, 0.0f, ITEM_PACKAGED, {.expiry_date = {28, 11, 2026}}},
        {103, "Veg Biryani",    80.0f, 20, 0, 0.0f, ITEM_COOKED,   {.prepared_time = {12, 15}}},
        {104, "Lunch Combo",   110.0f,  8, 0, 0.0f, ITEM_COMBO,    {.combo = {{103, 101, 0}, 2}}}
    };
    Date today = {19, 11, 2026};

    printf("sizeof(CanteenItem) = %zu bytes\n\n", sizeof(CanteenItem));
    record_sale(&menu[2], 6);   /* Normal sale: Veg Biryani */
    record_sale(&menu[3], 4);   /* Normal sale: Lunch Combo */
    record_sale(&menu[0], 3);   /* Normal sale: Fruit Juice */
    record_sale(&menu[3], 10);  /* Exceeds stock (only 4 left) -> rejected */

    warn_expiring_items(menu, 4, today);
    print_revenue_summary(menu, 4);
    return 0;
}
