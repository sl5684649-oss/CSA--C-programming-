#include <stdio.h>

enum kind { TEMPERATURE, HUMIDITY, STATUS };

struct reading_all_fields {
    enum kind type;
    float celsius;
    int percent;
    char status[8];
};

struct reading {
    enum kind type; /* tag: tells which union member is valid */
    union {
        float celsius;
        int percent;
        char status[8];
    } value;
};

void show(const struct reading *r)
{
    /* TODO 1: Use a switch on r->type to print only the valid union member */
    switch (r->type) {
        case TEMPERATURE:
            printf("Temp %.1f C\n", r->value.celsius);
            break;
        case HUMIDITY:
            printf("Humidity %d %%\n", r->value.percent);
            break;
        case STATUS:
            printf("Status %s\n", r->value.status);
            break;
        default:
            printf("Unknown packet type\n");
            break;
    }
}

int main(void)
{
    struct reading log[3] = {
        {TEMPERATURE, {.celsius = 31.5f}},
        {HUMIDITY,    {.percent = 68}},
        {STATUS,      {.status = "OK"}}
    };
    printf("sizeof(struct reading_all_fields) = %zu bytes\n", sizeof(struct reading_all_fields));
    printf("sizeof union = %zu, sizeof struct reading = %zu\n", sizeof log[0].value, sizeof log[0]);
    for (int i = 0; i < 3; i++) show(&log[i]);

    /* Task 3.4 Misuse Experiment: Store float temperature, read int humidity */
    struct reading misuse;
    misuse.type = TEMPERATURE;
    misuse.value.celsius = 31.5f;
    printf("Misuse Experiment (stored 31.5f, read .percent): %d (0x%08X IEEE-754 bits)\n",
           misuse.value.percent, (unsigned int)misuse.value.percent);
    return 0;
}
