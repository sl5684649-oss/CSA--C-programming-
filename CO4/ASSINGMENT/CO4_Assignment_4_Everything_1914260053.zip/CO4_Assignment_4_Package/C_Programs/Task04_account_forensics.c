#include <stdio.h>

struct account {
    int number;
    float balance;
};

/* Defect Demonstration Helper: Pass-by-value receives a stack copy */
void addInterestByValue(struct account a, float rate)
{
    printf("  [Inside addInterestByValue] Address of copy &a = %p\n", (void *)&a);
    a.balance = a.balance + a.balance * rate / 100.0f;
}

/* Repaired Function: Pass-by-pointer mutates caller's struct via -> */
void addInterest(struct account *a, float rate)
{
    if (a == NULL) return;
    a->balance = a->balance + a->balance * rate / 100.0f;
}

int main(void)
{
    struct account list[3] = {{101, 5000.0f}, {102, 12000.0f}, {103, 800.0f}};
    struct account *p = list;

    printf("--- Address Evidence (Pass-by-Value vs Caller) ---\n");
    printf("  [In main] Address of &list[0] = %p\n", (void *)&list[0]);
    addInterestByValue(list[0], 4.0f);
    printf("  Balance after pass-by-value = %.2f (Unchanged!)\n\n", list[0].balance);

    printf("--- Repaired Execution (Pass-by-Pointer with ->) ---\n");
    for (int i = 0; i < 3; i++) {
        addInterest(&list[i], 4.0f);
    }
    for (int i = 0; i < 3; i++) {
        printf("Account %d -> Updated Balance = %.2f\n", (p + i)->number, (p + i)->balance);
    }
    return 0;
}
